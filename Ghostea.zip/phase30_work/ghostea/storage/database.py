import json
import urllib.error
import urllib.parse
import urllib.request
import time
import os
import random

from ghostea.services.observability import OBSERVABILITY


class SupabaseREST:
    """
    Small dependency-free Supabase/PostgREST client.

    The server-side key must be supplied through SUPABASE_KEY and must
    never be committed to GitHub. This is intentionally implemented with
    urllib so Android/Termux does not need another database package.
    """

    def __init__(self, url: str, key: str):
        self.base = url.rstrip("/") + "/rest/v1"
        self.key = key
        self.timeout = self._env_float("SUPABASE_HTTP_TIMEOUT_SECONDS", 15.0, minimum=3.0, maximum=120.0)
        self.read_retries = self._env_int("SUPABASE_READ_RETRIES", 3, minimum=0, maximum=4)

    @staticmethod
    def _env_float(name, default, *, minimum=0.0, maximum=3600.0):
        try:
            value = float(os.getenv(name, str(default)).strip())
        except (TypeError, ValueError):
            return default
        if value != value or value in (float("inf"), float("-inf")):
            return default
        return max(minimum, min(value, maximum))

    @staticmethod
    def _env_int(name, default, *, minimum=0, maximum=2**31 - 1):
        try:
            value = int(os.getenv(name, str(default)).strip())
        except (TypeError, ValueError):
            return default
        return max(minimum, min(value, maximum))

    def _request(self, method, table, payload=None, query=None, prefer=None):
        url = f"{self.base}/{table}"
        if query:
            url += "?" + urllib.parse.urlencode(query, doseq=True)

        body = None
        if payload is not None:
            body = json.dumps(payload).encode("utf-8")

        headers = {
            "apikey": self.key,
            "Authorization": f"Bearer {self.key}",
            "Content-Type": "application/json",
        }
        if prefer:
            headers["Prefer"] = prefer

        req = urllib.request.Request(
            url,
            data=body,
            headers=headers,
            method=method,
        )

        # Only retry idempotent reads. Retrying POST/PATCH could duplicate an
        # insert when the server accepted it but the response was lost.
        attempts = self.read_retries if method.upper() == "GET" else 1
        started = time.monotonic()
        for attempt in range(attempts):
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as response:
                    raw = response.read().decode("utf-8")
                    result = [] if not raw else json.loads(raw)
                    OBSERVABILITY.observe_duration(
                        "supabase_request",
                        time.monotonic() - started,
                    )
                    OBSERVABILITY.emit(
                        "supabase_request",
                        method=method.upper(),
                        table=table,
                        status=int(response.status),
                        attempt=attempt + 1,
                    )
                    return result
            except urllib.error.HTTPError as error:
                OBSERVABILITY.emit(
                    "supabase_error",
                    level="WARNING",
                    method=method.upper(),
                    table=table,
                    status=int(error.code),
                    attempt=attempt + 1,
                )
                transient = error.code == 429 or 500 <= error.code <= 599
                if transient and attempt + 1 < attempts:
                    retry_after = error.headers.get("Retry-After")
                    try:
                        delay = float(retry_after)
                    except (TypeError, ValueError):
                        delay = 0.25 * (2 ** attempt)
                    delay = min(max(0.05, delay), 5.0)
                    time.sleep(delay + random.uniform(0, min(0.15, delay / 4)))
                    continue
                details = error.read().decode("utf-8", errors="replace")
                raise RuntimeError(
                    f"Supabase HTTP {error.code}: {details}"
                ) from error
            except (urllib.error.URLError, TimeoutError) as error:
                OBSERVABILITY.emit(
                    "supabase_error",
                    level="WARNING",
                    method=method.upper(),
                    table=table,
                    error_type=error.__class__.__name__,
                    attempt=attempt + 1,
                )
                if attempt + 1 < attempts:
                    retry_after = getattr(getattr(error, "headers", None), "get", lambda _name: None)("Retry-After")
                    try:
                        delay = float(retry_after)
                    except (TypeError, ValueError):
                        delay = 0.25 * (2 ** attempt)
                    delay = min(max(0.05, delay), 5.0)
                    time.sleep(delay + random.uniform(0, min(0.15, delay / 4)))
                    continue
                raise RuntimeError(f"Supabase connection failed: {error}") from error

    def select(self, table, query):
        return self._request("GET", table, query=query)

    def insert(self, table, payload, return_rows=False):
        prefer = "return=representation" if return_rows else "return=minimal"
        return self._request("POST", table, payload, prefer=prefer)

    def upsert(self, table, payload):
        return self._request(
            "POST",
            table,
            payload,
            prefer="resolution=merge-duplicates,return=representation",
        )

    def update(self, table, payload, query):
        return self._request("PATCH", table, payload, query=query, prefer="return=representation")

    def delete(self, table, query):
        return self._request("DELETE", table, query=query)

    def check_tables(self, tables):
        """Probe required PostgREST tables without downloading table data."""
        results = {}
        for table in tables:
            try:
                self.select(table, {"select": "*", "limit": "0"})
                results[table] = True
            except Exception:
                results[table] = False
        return results

    def count(self, table, query=None):
        """Return an exact PostgREST row count without downloading the table."""
        query = dict(query or {})
        query.setdefault("select", "id")
        url = f"{self.base}/{table}?" + urllib.parse.urlencode(query, doseq=True)
        headers = {
            "apikey": self.key,
            "Authorization": f"Bearer {self.key}",
            "Content-Type": "application/json",
            "Prefer": "count=exact",
            "Range": "0-0",
        }
        req = urllib.request.Request(url, headers=headers, method="GET")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                content_range = response.headers.get("Content-Range", "")
                total = content_range.rsplit("/", 1)[-1] if "/" in content_range else "0"
                return int(total) if total != "*" else 0
        except urllib.error.HTTPError as error:
            details = error.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Supabase HTTP {error.code}: {details}") from error
        except urllib.error.URLError as error:
            raise RuntimeError(f"Supabase connection failed: {error}") from error

    def close(self):
        """HTTP provider has no persistent socket to close."""
        return None

    def health_check(self):
        """Perform a lightweight PostgREST table probe for connectivity."""
        self.select("ghostea_schema_meta", {"select": "id", "limit": "0"})
        return True
