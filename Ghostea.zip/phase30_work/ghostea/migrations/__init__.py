"""Versioned Ghostea database migrations."""
