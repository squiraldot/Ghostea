-- Ghostea database schema
-- Run this canonical PostgreSQL schema against the selected database. For managed mode, use the Supabase SQL Editor; for self-hosted mode, run it against the VPS PostgreSQL database.
-- The application uses the server-side SUPABASE_KEY only in managed mode.
-- Never expose that key in the Vercel browser bundle.

-- Phase 1: canonical chat registry. One row per Telegram chat used by Ghostea.
-- This stores capabilities only; moderation settings remain group-scoped for now.
create table if not exists ghostea_chat_registry (
    chat_id bigint primary key,
    chat_type text not null check (chat_type in ('group', 'supergroup')),
    title text,
    username text,
    -- Telegram's public/private signal for group chats is the presence of a
    -- public username. Basic groups cannot be assigned a public username.
    visibility text not null default 'private'
        check (visibility in ('private', 'public')),
    is_forum boolean not null default false,
    first_seen_at timestamptz not null default now(),
    last_seen_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

create index if not exists idx_ghostea_chat_registry_forum
    on ghostea_chat_registry (is_forum);

-- A basic Telegram group cannot be a Forum; forum is a supergroup
-- capability. Keep the invariant in the database as well as application code.
do $$
begin
    if not exists (
        select 1
        from pg_constraint
        where conname = 'ghostea_chat_registry_forum_supergroup_only'
          and conrelid = 'ghostea_chat_registry'::regclass
    ) then
        alter table ghostea_chat_registry
            add constraint ghostea_chat_registry_forum_supergroup_only
            check (is_forum = false or chat_type = 'supergroup');
    end if;
end $$;

-- Safe upgrade for databases created before Phase 11.
alter table ghostea_chat_registry
    add column if not exists visibility text not null default 'private';

alter table ghostea_chat_registry
    add column if not exists is_linked boolean not null default true;

alter table ghostea_chat_registry
    add column if not exists linked_by text;

create index if not exists idx_ghostea_chat_registry_linked
    on ghostea_chat_registry (is_linked);

do $$
begin
    if not exists (
        select 1
        from pg_constraint
        where conname = 'ghostea_chat_registry_visibility'
          and conrelid = 'ghostea_chat_registry'::regclass
    ) then
        alter table ghostea_chat_registry
            add constraint ghostea_chat_registry_visibility
            check (visibility in ('private', 'public'));
    end if;
end $$;

create index if not exists idx_ghostea_chat_registry_visibility
    on ghostea_chat_registry (visibility);

-- ============================================================
-- Ghostea Phase 3 — Forum topic persistence foundation
-- ============================================================
-- Topics are scoped by their parent chat. topic_id is NOT globally unique.
-- These tables are intentionally additive: existing warnings, settings,
-- reputation, verification and security state remain chat-scoped until the
-- later roadmap phases explicitly migrate them.
create table if not exists ghostea_topic_registry (
    chat_id bigint not null,
    topic_id bigint not null,
    name text,
    is_active boolean not null default true,
    is_closed boolean not null default false,
    is_hidden boolean not null default false,
    first_seen_at timestamptz not null default now(),
    last_seen_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    primary key (chat_id, topic_id)
);

alter table if exists ghostea_topic_registry
    add column if not exists is_hidden boolean not null default false;

create index if not exists idx_ghostea_topic_registry_chat_activity
    on ghostea_topic_registry(chat_id, is_active, updated_at desc);

create index if not exists idx_ghostea_topic_registry_chat_topic
    on ghostea_topic_registry(chat_id, topic_id);

create table if not exists ghostea_topic_settings (
    chat_id bigint not null,
    topic_id bigint not null,
    settings jsonb not null default '{}'::jsonb,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    primary key (chat_id, topic_id),
    constraint ghostea_topic_settings_object
        check (jsonb_typeof(settings) = 'object')
);

create index if not exists idx_ghostea_topic_settings_chat
    on ghostea_topic_settings(chat_id, updated_at desc);


create table if not exists ghostea_group_settings (
    chat_id bigint primary key,
    max_warnings integer not null default 3,
    mute1_minutes integer not null default 2,
    mute2_minutes integer not null default 5,
    flood_window_seconds integer not null default 8,
    flood_message_limit integer not null default 6,
    flood_mute_minutes integer not null default 10,
    blocked_link_action text not null default 'delete',
    abuse_filter_enabled boolean not null default true,
    spam_filter_enabled boolean not null default true,
    link_filter_enabled boolean not null default true,
    flood_protection_enabled boolean not null default true,
    welcome_enabled boolean not null default true,
    antiraid_enabled boolean not null default true,
    antiraid_join_limit integer not null default 8,
    antiraid_window_seconds integer not null default 20,
    antiraid_lock_minutes integer not null default 10,
    auto_cleanup_enabled boolean not null default false,
    verification_enabled boolean not null default true,
    verification_timeout_seconds integer not null default 120,
    min_account_age_days integer not null default 0,
    new_member_restriction_minutes integer not null default 0,
    repeated_message_window_seconds integer not null default 60,
    repeated_message_limit integer not null default 3,
    mention_spam_limit integer not null default 6,
    max_message_length integer not null default 4000,
    warning_decay_enabled boolean not null default true,
    warning_decay_days integer not null default 30,
    cleanup_max_age_days integer not null default 30,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

create table if not exists ghostea_warnings (
    chat_id bigint not null,
    user_id bigint not null,
    count integer not null default 0,
    updated_at timestamptz not null default now(),
    primary key (chat_id, user_id)
);

create table if not exists ghostea_warning_history (
    id bigint generated by default as identity primary key,
    chat_id bigint not null,
    user_id bigint not null,
    reason text not null,
    source text not null,
    active boolean not null default true,
    created_at timestamptz not null default now()
);
create index if not exists idx_ghostea_warning_history_chat_user
on ghostea_warning_history(chat_id, user_id, created_at desc);

-- Safe upgrade for databases created by earlier Ghostea phases.
alter table ghostea_warning_history
  add column if not exists active boolean not null default true;

create index if not exists idx_ghostea_warning_history_active
on ghostea_warning_history(chat_id, user_id, active, created_at desc);

create table if not exists ghostea_custom_filters (
    id bigint generated by default as identity primary key,
    chat_id bigint not null,
    filter_type text not null,
    value text not null,
    enabled boolean not null default true,
    created_at timestamptz not null default now(),
    unique(chat_id, filter_type, value)
);

create table if not exists ghostea_moderation_logs (
    id bigint generated by default as identity primary key,
    chat_id bigint not null,
    user_id bigint,
    topic_id bigint,
    action text not null,
    reason text,
    details text,
    created_at timestamptz not null default now()
);
create index if not exists idx_ghostea_moderation_logs_chat
on ghostea_moderation_logs(chat_id, created_at desc);
create index if not exists idx_ghostea_moderation_logs_chat_topic_time
on ghostea_moderation_logs(chat_id, topic_id, created_at desc);

-- Safe upgrade for databases created before Phase 6.
alter table ghostea_moderation_logs
  add column if not exists topic_id bigint;

create index if not exists idx_ghostea_moderation_logs_chat_topic_user_time
on ghostea_moderation_logs(chat_id, topic_id, user_id, created_at desc);

create table if not exists ghostea_join_events (
    id bigint generated by default as identity primary key,
    chat_id bigint not null,
    user_id bigint not null,
    joined_at timestamptz not null default now()
);
create index if not exists idx_ghostea_join_events_chat
on ghostea_join_events(chat_id, joined_at desc);

create table if not exists ghostea_raid_events (
    id bigint generated by default as identity primary key,
    chat_id bigint not null,
    action text not null,
    details text,
    created_at timestamptz not null default now()
);

create table if not exists ghostea_verifications (
    chat_id bigint not null,
    user_id bigint not null,
    token text not null,
    expires_at timestamptz not null,
    verified boolean not null default false,
    created_at timestamptz not null default now(),
    primary key(chat_id, user_id)
);

create table if not exists ghostea_reputation (
    chat_id bigint not null,
    user_id bigint not null,
    score integer not null default 0,
    positive_actions integer not null default 0,
    negative_actions integer not null default 0,
    updated_at timestamptz not null default now(),
    primary key(chat_id, user_id)
);

create table if not exists ghostea_cleanup_runs (
    id bigint generated by default as identity primary key,
    chat_id bigint not null,
    cutoff_at timestamptz not null,
    deleted_count integer not null default 0,
    created_at timestamptz not null default now()
);

create table if not exists ghostea_health_events (
    id bigint generated by default as identity primary key,
    chat_id bigint,
    status text not null,
    details text,
    created_at timestamptz not null default now()
);
create index if not exists idx_ghostea_health_events_time
on ghostea_health_events(created_at desc);

-- ============================================================
-- Ghostea Phase 18 — Migration & Lifecycle 2.0
-- The existing journal remains the durable recovery boundary for Group -> Supergroup
-- migrations. Phase 18 retries completed-table migrations safely and reconciles
-- authoritative post-migration Telegram metadata on the next update.

-- Ghostea Phase 10 — Telegram chat migration journal
-- ============================================================
-- Telegram may migrate a basic group into a supergroup. This journal makes
-- state migration resumable and prevents accidental target overwrites.
create table if not exists ghostea_chat_migrations (
    old_chat_id bigint not null,
    new_chat_id bigint not null,
    status text not null check (status in ('running','completed','blocked')),
    completed_tables jsonb not null default '[]'::jsonb,
    error text,
    updated_at timestamptz not null default now(),
    primary key (old_chat_id, new_chat_id)
);

create index if not exists idx_ghostea_chat_migrations_status
on ghostea_chat_migrations(status, updated_at desc);


-- ============================================================
-- Ghostea Phase 10 — User management audit trail
-- ============================================================
create table if not exists ghostea_user_admin_actions (
    id bigint generated by default as identity primary key,
    chat_id bigint not null,
    target_user_id bigint not null,
    admin_user_id bigint,
    action text not null,
    details text,
    created_at timestamptz not null default now()
);

create index if not exists idx_ghostea_user_admin_actions_chat
on ghostea_user_admin_actions(chat_id, created_at desc);

create index if not exists idx_ghostea_user_admin_actions_target
on ghostea_user_admin_actions(chat_id, target_user_id, created_at desc);


-- ============================================================
-- Ghostea Phase 11 — Persistent security/recovery state
-- ============================================================
create table if not exists ghostea_security_locks (
    chat_id bigint not null,
    lock_type text not null,
    expires_at timestamptz not null,
    original_permissions jsonb not null default '{}'::jsonb,
    created_at timestamptz not null default now(),
    primary key (chat_id, lock_type)
);

create index if not exists idx_ghostea_security_locks_expiry
on ghostea_security_locks(expires_at);


-- ============================================================
-- Ghostea Phase 14 — Scalable user directory + RBAC admins
-- ============================================================

create table if not exists ghostea_admins (
    id bigint generated by default as identity primary key,
    username text not null unique,
    display_name text not null default '',
    password_hash text not null,
    role text not null check (role in ('super_admin','admin','moderator','viewer')),
    enabled boolean not null default true,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    last_login_at timestamptz
);

create index if not exists idx_ghostea_admins_role_enabled
on ghostea_admins(role, enabled);

create table if not exists ghostea_user_directory (
    chat_id bigint not null,
    user_id bigint not null,
    first_seen_at timestamptz not null default now(),
    last_activity timestamptz not null default now(),
    primary key(chat_id, user_id)
);

create index if not exists idx_ghostea_user_directory_chat_activity
on ghostea_user_directory(chat_id, last_activity desc);
create index if not exists idx_ghostea_warning_history_chat_user_time
on ghostea_warning_history(chat_id, user_id, created_at desc);

create index if not exists idx_ghostea_moderation_logs_chat_user_time
on ghostea_moderation_logs(chat_id, user_id, created_at desc);

create index if not exists idx_ghostea_join_events_chat_user_time
on ghostea_join_events(chat_id, user_id, joined_at desc);


-- Keep this table lightweight: it is an index of known users, not a copy of
-- Telegram's entire membership list.
create or replace view ghostea_user_directory_view as
with known as (
    select chat_id, user_id, min(first_seen_at) as first_seen_at,
           max(last_activity) as last_activity
    from ghostea_user_directory
    group by chat_id, user_id

    union

    select chat_id, user_id, min(joined_at), max(joined_at)
    from ghostea_join_events
    group by chat_id, user_id

    union

    select chat_id, user_id, min(created_at), max(created_at)
    from ghostea_moderation_logs
    where user_id is not null
    group by chat_id, user_id

    union

    select chat_id, user_id, min(created_at), max(created_at)
    from ghostea_warning_history
    group by chat_id, user_id

    union

    select chat_id, user_id, min(updated_at), max(updated_at)
    from ghostea_reputation
    group by chat_id, user_id
)
select
    k.chat_id,
    k.user_id,
    k.first_seen_at,
    k.last_activity,
    coalesce(w.count, 0) as warnings,
    coalesce(l.actions, 0) as actions,
    coalesce(r.score, 0) as reputation
from known k
left join ghostea_warnings w
  on w.chat_id = k.chat_id and w.user_id = k.user_id
left join (
    select chat_id, user_id, count(*)::integer as actions
    from ghostea_moderation_logs
    where user_id is not null
    group by chat_id, user_id
) l on l.chat_id = k.chat_id and l.user_id = k.user_id
left join ghostea_reputation r
  on r.chat_id = k.chat_id and r.user_id = k.user_id;

-- Phase 14 RBAC bootstrap:
-- Set GHOSTEA_SUPERADMIN_USERNAME (optional; defaults to "superadmin")
-- and keep GHOSTEA_ADMIN_PASSWORD in Render. The first successful login
-- creates that account as the initial Super Admin with a scrypt password hash.

-- ============================================================
-- PHASE 6 — DM upload workflow sessions
-- Durable state for /uploadconfig and /uploadflag. Sessions contain
-- short-lived workflow payloads only; published resources are added later.
-- ============================================================
create table if not exists ghostea_upload_sessions (
    session_id text primary key,
    user_id bigint not null,
    chat_id bigint not null,
    topic_id bigint,
    mode text not null check (mode in ('resource', 'flag')),
    state text not null,
    payload jsonb not null default '{}'::jsonb,
    created_at timestamptz not null default now(),
    expires_at timestamptz not null,
    updated_at timestamptz not null default now(),
    constraint ghostea_upload_sessions_payload_object
        check (jsonb_typeof(payload) = 'object'),
    constraint ghostea_upload_sessions_topic_positive
        check (topic_id is null or topic_id >= 1)
);

create index if not exists idx_ghostea_upload_sessions_user_active
    on ghostea_upload_sessions(user_id, state, expires_at);
create index if not exists idx_ghostea_upload_sessions_expiry
    on ghostea_upload_sessions(expires_at);
create index if not exists idx_ghostea_upload_sessions_target
    on ghostea_upload_sessions(chat_id, topic_id, updated_at desc);

-- ============================================================
-- PHASE 7 — Published resource / flag registry
-- Durable metadata for Telegram-published resources and download callbacks.
-- ============================================================
create table if not exists ghostea_resources (
    resource_id text primary key,
    workflow_session_id text unique,
    chat_id bigint not null,
    topic_id bigint,
    mode text not null check (mode in ('resource', 'flag')),
    source_kind text not null check (source_kind in ('document', 'photo', 'video', 'audio', 'animation', 'url')),
    source_file_id text,
    source_url text,
    caption text,
    description text not null,
    main_flag text,
    sub_flags text,
    published_message_id bigint,
    published_extra_message_id bigint,
    created_by bigint not null,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    constraint ghostea_resources_target_topic_positive
        check (topic_id is null or topic_id >= 1),
    constraint ghostea_resources_source_exclusive
        check ((source_file_id is not null and source_url is null) or (source_file_id is null and source_url is not null))
);

-- Phase 18 — Self-hosted resource storage metadata.
-- Additive columns let VPS mode keep file bytes locally while managed mode
-- continues to use Telegram file IDs / existing remote storage behavior.
alter table if exists ghostea_resources
    add column if not exists storage_key text;

alter table if exists ghostea_resources
    add column if not exists storage_filename text;

alter table if exists ghostea_resources
    add column if not exists storage_size bigint;

alter table if exists ghostea_resources
    add column if not exists storage_content_type text;

create index if not exists idx_ghostea_resources_target
    on ghostea_resources(chat_id, topic_id, created_at desc);
create index if not exists idx_ghostea_resources_created_by
    on ghostea_resources(created_by, created_at desc);

-- ============================================================
-- PHASE 9 — Database & Data Integrity
-- Supabase SQL Editor safe: no PL/pgSQL dollar-quoted blocks in this migration.
-- This section is rerunnable and does not modify or delete historical rows.

create table if not exists ghostea_schema_meta (
    schema_name text primary key,
    schema_version integer not null,
    applied_at timestamptz not null default now()
);

insert into ghostea_schema_meta(schema_name, schema_version)
values ('ghostea', 9)
on conflict (schema_name) do update
set schema_version = greatest(ghostea_schema_meta.schema_version, excluded.schema_version);

-- Monitoring/query indexes.
create index if not exists idx_ghostea_resources_chat_created
    on ghostea_resources(chat_id, created_at desc);
create index if not exists idx_ghostea_upload_sessions_user_updated
    on ghostea_upload_sessions(user_id, updated_at desc);

-- Concurrency support: this is intentionally a normal index rather than a
-- unique partial index because legacy databases may already contain more than
-- one active session. The application cancels the previous session before
-- creating a new one, so upgrading an existing DB cannot fail on old data.
create index if not exists idx_ghostea_upload_sessions_user_nonterminal
    on ghostea_upload_sessions(user_id)
    where state not in ('cancelled', 'expired');


-- ============================================================
-- PHASE 11 — 50K+ Load & Scale Hardening
-- ============================================================
-- These are additive, idempotent indexes. No destructive migration.
-- They target the hot paths used by moderation history, user lookup,
-- topic resolution, and dashboard resource monitoring.

CREATE INDEX IF NOT EXISTS idx_ghostea_moderation_logs_chat_created
    ON ghostea_moderation_logs(chat_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_ghostea_moderation_logs_chat_user_created
    ON ghostea_moderation_logs(chat_id, user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_ghostea_user_directory_chat_activity
    ON ghostea_user_directory(chat_id, last_activity DESC);

CREATE INDEX IF NOT EXISTS idx_ghostea_join_events_chat_created
    ON ghostea_join_events(chat_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_ghostea_topic_registry_chat_active_updated
    ON ghostea_topic_registry(chat_id, is_active, updated_at DESC);

CREATE INDEX IF NOT EXISTS idx_ghostea_resources_chat_topic_created
    ON ghostea_resources(chat_id, topic_id, created_at DESC);


-- ============================================================
-- PHASE 27 — Versioned database migration ledger
-- ============================================================
-- The canonical schema is always created at the latest migration version.
-- Existing databases upgrade through ghostea/migrations/*.sql instead of
-- re-running the whole schema file.
create table if not exists ghostea_schema_migrations (
    version integer primary key,
    name text not null,
    checksum text not null,
    applied_at timestamptz not null default now()
);

insert into ghostea_schema_migrations(version, name, checksum)
values (10, 'schema_migration_ledger', 'b75b790f4f9152c747b1d6427761acbb2732af0195c117a4ad39b4c8a6fbe1c1')
on conflict (version) do nothing;

update ghostea_schema_meta
set schema_version = greatest(schema_version, 10)
where schema_name = 'ghostea';

-- ============================================================
-- PHASE 29 — Durable background job queue
-- ============================================================
create table if not exists ghostea_background_jobs (
    job_id text primary key,
    job_type text not null,
    payload jsonb not null default '{}'::jsonb,
    status text not null default 'pending'
        check (status in ('pending','running','succeeded','failed','dead')),
    attempts integer not null default 0 check (attempts >= 0),
    max_attempts integer not null default 5 check (max_attempts between 1 and 20),
    available_at timestamptz not null default now(),
    locked_by text,
    locked_at timestamptz,
    last_error text,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    completed_at timestamptz
);
create index if not exists idx_ghostea_background_jobs_ready
    on ghostea_background_jobs(status, available_at);
create index if not exists idx_ghostea_background_jobs_locked
    on ghostea_background_jobs(status, locked_at);
create index if not exists idx_ghostea_background_jobs_type
    on ghostea_background_jobs(job_type, created_at desc);


-- Phase 29 migration ledger entry.
insert into ghostea_schema_migrations(version, name, checksum)
values (11, 'background_jobs', '7d69c9ef246bc233e160ab2d347f35f6ac08d54279d81a31e933828778d88ec0')
on conflict (version) do nothing;

update ghostea_schema_meta
set schema_version = greatest(schema_version, 11)
where schema_name = 'ghostea';
